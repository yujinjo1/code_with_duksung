package com.example.testapplication

data class Book(
    var bookid:Int,
    var bookName:String,
    var bookGenre:String,
    var bookInform:String
)
