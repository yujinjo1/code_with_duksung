package com.example.myapplication

data class Review(
    var nickname: String,
    var reviewBook : String,
    var stars:Int,
    var content: String
)
