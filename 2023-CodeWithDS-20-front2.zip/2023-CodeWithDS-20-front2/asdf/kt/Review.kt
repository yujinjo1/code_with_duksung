package com.example.myapplication

data class Review(
    var title :String,
    var star: Int,
    var content: String
)
